const AWS = require('aws-sdk')
AWS.config.update({region: process.env.AWS_REGION})
const eventbridge = new AWS.EventBridge()


exports.handler = async (event) => {
    // TODO implement

    const params = {
        Entries: [ 
          {
            Detail: JSON.stringify({
              "state": "created",
              "id": "123"
            }),
            DetailType: 'New order',
            Source: 'demo.orders',
            Time: new Date 
          }
        ]
      }
      const result = await eventbridge.putEvents(params).promise()
    
      console.log('--- Params ---')
      console.log(params)
      console.log('--- Response ---')
      console.log(result)
          
    
    

    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda Step 2 !!' + params + " " + result),
    };
    return response;
};
